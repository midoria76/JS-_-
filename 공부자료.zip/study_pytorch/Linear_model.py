import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim

x = torch.FloatTensor([[1],[2],[3],[4]])
y = torch.FloatTensor([[2],[4],[7],[8]])

class Linear_model(nn.Module):
    def __init__(self):
        super().__init__()
        self.linear = nn.Linear(1,1)
    def forward(self, x):
        return self.linear(x)
    
model = Linear_model()
optimizer = torch.optim.SGD(model.parameters(), lr = 0.1)

nb_epochs = 1000

for epoch in range(nb_epochs+1):
    predict = model(x)
    cost = F.mse_loss(predict, y)
    optimizer.zero_grad()
    cost.backward()
    optimizer.step()
    
    if epoch % 100 == 0:
        # 100번마다 로그 출력
      print('Epoch {:4d}/{} Cost: {:.6f}'.format(
          epoch, nb_epochs, cost.item()
      ))
      
input = torch.FloatTensor([[1],[5],[6]])
print(model(input))