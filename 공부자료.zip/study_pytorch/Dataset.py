#https://inhovation97.tistory.com/37
#https://data-panic.tistory.com/13

# from PIL import Image
# img = Image.open('C:/Users/Galaxy Book Pro 360/Desktop/내꺼/진곽 과제/정보/다운로드.png')
# img.show()

from PIL import Image
import matplotlib
import matplotlib.pyplot as plt
import torch
from torch.utils.data import Dataset, DataLoader
import numpy as np
import torchvision
from torchvision import transforms
import time
trans = transforms.Compose([transforms.Resize((100,100)),
                            transforms.ToTensor(),
                            transforms.Normalize((0.5,0.5,0.5),(0.5,0.5,0.5))
                            ])

trainset = torchvision.datasets.ImageFolder(root = 'C:/Users/Galaxy Book Pro 360/Desktop/내꺼/이미지 다운',transform=trans)
trainloader = DataLoader(trainset, batch_size=16,shuffle=True)

def imshow(img):
    img = img / 2 + 0.5 #unnormalize
    np_img = img.numpy()
    plt.imshow(np.transpose(np_img,(1,2,0)))
    

# dataiter = iter(trainloader)
# images, labels = dataiter.next()
# print(images.shape)
# imshow(torchvision.utils.make_grid(images, nrow = 4))
for item in trainloader:
    print(item)