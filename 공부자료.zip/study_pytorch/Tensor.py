import torch
import numpy as np

data = [[1,2], [3,4], [5,6]]
data1 = [[1,2,3],[4,5,6]]

tensor_data1 = torch.tensor(data) #List를 Tensor형으로 변환
tensor_data2 = torch.ones_like(torch.tensor(data1))
print(tensor_data1) #data와 tensor_data는 출력 같음

#print(tensor_data1.sum())
#전체 요소 합

# np.array(data), torch.from_numpy(np_array)

#x_ones = torch.ones_like(data) # x_data의 속성을 유지
#print(f"Ones Tensor: \n {x_ones} \n")

#x_rand = torch.rand_like(data, dtype=torch.float) # x_data의 속성을 덮어씀
#print(f"Random Tensor: \n {x_rand} \n")

####################################################################

# tensor_data3 = torch.matmul(tensor_data1,tensor_data1)
# matmul 행렬 곱
# print("matmul\n", tensor_data3)