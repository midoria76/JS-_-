import torch
import numpy as np

data = [[1,2],[3,4],[5,6]]
arr = np.arange(0,6,1)
arr = arr.reshape(3,-1)
# print(data,arr ,sep = '\n')


tensor_data = torch.tensor(data) #기본형을 tensor형으로 변환
tensor_arr = torch.from_numpy(arr) #numpy 형을 tensor형으로 변환
# print(tensor_data, tensor_arr, sep = '\n')


ones_like_tensor = torch.ones_like(tensor_arr) #tensor_arr와 형식(차원, 행, 열... ) 모두 같지만, 값은 모두 1로 채운 새로운 tensor생성
rand_like_tensor = torch.rand_like(tensor_data, dtype=torch.float32) #ones_like와 기능은 비슷하며, 차이점은 값을 1 뿐만아니라 랜덤값으로 채우며 이를 지정하니느 dtype 을 지정해줘야함.
# print(ones_like_tensor, rand_like_tensor, sep = '\n')


shape = (4,3)
zero_tensor = torch.zeros(shape) #shape(tuple로 지정된..)형식에 맞는 tensor를 새로 생성, 이 때 zeros이므로 값을 0 으로 채움. @@@ like만 빼주면 됨... -> ones, zeros, rand ###torch.zeros(5) 해도됨...
# print(zero_tensor)




