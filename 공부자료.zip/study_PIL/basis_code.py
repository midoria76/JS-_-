from PIL import Image
img = Image.open('C:/Users/Galaxy Book Pro 360/Downloads/cats/3.jpg')

## 이미지 파일명
print('filename:', img.filename)

## 이미지 형식
print('format:',img.format)

## 이미지 크기
print('size:', img.size)

## 이미지 너비
print('width', img.width)

## 이미지 높이
print('height', img.height)

## 이미지의 색상 모드
print('mode', img.mode)



img.show()
