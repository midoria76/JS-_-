from PIL import Image
import numpy as np
img = Image.open('C:/Users/Galaxy Book Pro 360/Downloads/cats/3.jpg')

numpy_arr = np.array(img)
print(numpy_arr)

image = Image.fromarray(numpy_arr)
image.show()