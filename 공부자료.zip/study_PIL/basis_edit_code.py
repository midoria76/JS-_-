from PIL import Image
img = Image.open('C:/Users/Galaxy Book Pro 360/Downloads/cats/3.jpg')
img_resized = img.resize((400,300)) #사이즈 조정
img_cropped = img.crop((100,100,500,500)) #그림 자르기
img_rotated = img.rotate(90) #그림 회전
img_flipped_LR = img.transpose(Image.FLIP_LEFT_RIGHT) #좌우대칭

#img.show()
#img_resized.show()
#img_cropped.show()
#img_rotated.show()
#img_flipped_LR.show()