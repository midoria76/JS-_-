import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
from torchvision import datasets, transforms
from PIL import Image
import matplotlib
import matplotlib.pyplot as plt
import torch
from torch.utils.data import Dataset, DataLoader
import numpy as np
import torchvision
from torchvision import transforms

trans = transforms.Compose([transforms.Resize((32,32)),
                            transforms.ToTensor(),
                            transforms.Normalize((0.5,0.5,0.5),(0.5,0.5,0.5))
                            ])
path = 'C:/Users/Galaxy Book Pro 360/Desktop/내꺼/이미지 다운'
trainset = torchvision.datasets.ImageFolder(root = path,transform=trans)
trainloader = DataLoader(trainset, batch_size=16,shuffle=True)

testset = torchvision.datasets.ImageFolder(root=path, transform=trans)
testloader = torch.utils.data.DataLoader(dataset=testset, batch_size=16, shuffle=True)

class CNN(nn.Module):
    def __init__(self) : 
        super(CNN,self).__init__() 
        self.layer = nn.Sequential(
            nn.Conv2d(3,16,5),
            nn.ReLU(),
            nn.Conv2d(16,32,5),
            nn.ReLU(),
            nn.MaxPool2d(2,2),
            nn.Conv2d(32,64,5),
            nn.ReLU(),
            nn.MaxPool2d(2,2)
        )
        self.fc_layer = nn.Sequential(
            nn.Linear(64*4*4,100),
            nn.ReLU(),
            nn.Linear(100,17)
        )
        #self.layer : CNN이 끝난 이후, 최종적으로 나오는 결과물은 [batch_size,64,3,3]입니다.
        #즉, 256개의 이미지 묶음씩 64개의 필터, (3x3)의 이미지가 남게 되는것으로, pixel갯수로 따지면 64*3*3이 나오게 되는것입니다.
        #따라서, 64*3*3의 결과값을 nn.Linear(100,10)을 통해 최종적으로 10개의 값이 나오게하는데
        #이 10개의 값이 내가 넣은 이미지가 0~9(10개)중 어떤것일지에 대한 각각의 확률입니다.
    def forward(self,x):
        # print(x.shape, '시작시작시작시작<<<<<<<,')
        out = self.layer(x)
        # print(out.shape, '<<<<<<<,')
        out = out.view(16, -1)
        # print(out.shape, '<<<<<<<,')
        out = self.fc_layer(out)
        return out
    

device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
  #이부분은 굳이 안해주셔도 됩니다. GPU를 사용할 수 없는경우 CPU를 쓰겠다는 것으로, 이부분을 주석처리하고
  # model = CNN()로만 해주셔도 됩니다.
model = CNN().to(device)
loss_func = nn.CrossEntropyLoss()
optimizer = torch.optim.Adam(model.parameters(),lr=0.01)
#Cross Entropy Loss function, Adam optimizer
 
num_epoch = 1000
loss_arr = []

print(len(trainset.classes))



for epoch in range(10):
    for index, (data, target) in enumerate(trainloader):
        if(len(data) != 16):
            continue
        optimizer.zero_grad()  # 기울기 초기화
        output = model(data)
        loss = loss_func(output, target)
        loss.backward()  # 역전파
        optimizer.step()
        
        if index % 10 == 0:
            print("loss of {} epoch, {} index : {}".format(epoch, index, loss.item()))