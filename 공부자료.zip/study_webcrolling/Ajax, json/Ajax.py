import requests
import json
import pyautogui

keyword = ['ㄱ','ㄴ','ㄷ','ㄹ','ㅁ','ㅂ','ㅅ','ㅇ','ㅈ','ㅊ','ㅌ','ㅋ','ㅍ','ㅎ']
main_keyword = pyautogui.prompt("키워드 입력")

f = open(f'C:/Users/Galaxy Book Pro 360/Desktop/내꺼/연관 검색어/{main_keyword}.txt', 'w', encoding = 'utf-8')

for sub in keyword:
    input = main_keyword + ' ' + sub
    res = requests.get(f'https://ac.search.naver.com/nx/ac?q={input}&con=0&frm=nv&ans=2&r_format=json&r_enc=UTF-8&r_unicode=0&t_koreng=1&run=2&rev=4&q_enc=UTF-8&st=100&_callback=_jsonp_10')
    ori_data = res.text.split("_jsonp_10(")
    data = ori_data[1][:-1]
    dic_data = json.loads(data)
    f.write(sub + '\n')
    for item in dic_data["items"][0]:
        f.write(item[0] + '\n')
    f.write('\n')
        
f.close