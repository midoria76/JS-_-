import requests
from bs4 import BeautifulSoup
import urllib.request
import pyautogui
import os


search_name = pyautogui.prompt('찾을 내용을 검색하세요')
save_path = f'C:/Users/Galaxy Book Pro 360/Desktop/내꺼/이미지 다운/{search_name}'
url = f'https://search.naver.com/search.naver?where=image&sm=tab_jum&query={search_name}'
res = requests.get(url)
soup = BeautifulSoup(res.content, "html.parser")
select_data = soup.find_all('img')
# print(select_data)

n = 1

if not os.path.exists(save_path):
    os.mkdir(save_path)

for item in select_data:
    src = item.get('src')
    # src_url = url + '/' + src
    path = f'{save_path}/{search_name}{n}.png'
    # print(src)
    print(path)
    try:
        urllib.request.urlretrieve(src, path)
    except:
        print('Error')
    n+=1
    
    