import requests
from bs4 import BeautifulSoup

def web_crawling_text(url, tag):
    return_content = list()
    return_url = list()
    res = requests.get(url)
    soup = BeautifulSoup(res.content, "html.parser")
    sel_data = soup.select(tag)
    
    for item in sel_data:
        return_content.append(item.get_text())
        return_url.append(item.attrs['href'])
    return return_content, return_url


def web_crawling_href(url, tag):
    return_data = list()
    res = requests.get(url)
    soup = BeautifulSoup(res.content, 'html.parser')
    data = soup.select(tag)
    
    for item in data:
        return_data.append(item['href'])
    return return_data

print(web_crawling_text('https://rirosoft.com/','#notice_template > li > a'))