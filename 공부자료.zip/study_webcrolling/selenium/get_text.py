from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.common.by import By

# 브라우저 꺼짐 방지
chrome_options = Options()
chrome_options.add_experimental_option('detach', True)

# 에러 메시지 없애기
chrome_options.add_experimental_option('excludeSwitches', ["enable-logging"])

# 크롬 드라이버 자동 업데이트
service = Service(executable_path = ChromeDriverManager().install())
driver = webdriver.Chrome(service=service, options=chrome_options)

# 주소 이동
driver.implicitly_wait(5) #로딩 될때까지 5초 기다림
driver.maximize_window() #화면 최대화
driver.get("https://codechacha.com/ko/python-join-path-filename/") #이동


# ★ 아이디 입력 ★
contents = driver.find_elements(By.CSS_SELECTOR, ".table-of-contents") # id태그를 찾기 (copy -> copy_selector값...)
for content in contents:
    print(content.text)