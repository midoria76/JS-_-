import os

file_tr = 'C:/Users/Galaxy Book Pro 360/Desktop/내꺼/Download정리파일'
file_name = ['exe', 'txt', 'hwp','hwpx', 'pptx','pdf','xlsx','zip','png','csv','jpg','mp4','docx','svg']
find_path = 'C:/Users/Galaxy Book Pro 360/Downloads'
file_list = os.listdir(find_path)
#print(file_list)


for item in file_name:
    destination = file_tr + '/' + item
    if not os.path.exists(destination):
        os.mkdir(destination)

for item in file_list:
    name, ext = os.path.splitext(item)
    for ext_item in file_name:
        if ext == '.' + ext_item:
            move_file_path = file_tr + '/' + ext_item
            os.rename(find_path + '/' + item, move_file_path + '/' + item)
            print(find_path + '/' + item,'     ', move_file_path + '/' + item)
            print('')
    