import requests
from bs4 import BeautifulSoup

url = 'http://google.com'
respone = requests.get(url)

if respone.status_code == 200:
    html = respone.text
    soup = BeautifulSoup(html, 'html.parser')
    for meta in soup.head.find_all('meta'):
        print(meta.get('content'))