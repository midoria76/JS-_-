import pyautogui
pyautogui.mouseInfo()

# 절대 좌표로 이동
pyautogui.moveTo(100, 100)                 # 100, 100 위치로 즉시 이동
pyautogui.moveTo(200, 200, duration=0.5)   # 200, 200 위치로 0.5초간 이동


# 상대 좌표로 이동
pyautogui.move(100, 100, duration=1)    # 현재 위치 기준으로 100, 100만큼 1초간 이동

# 이동 & 클릭
pyautogui.click(200, 200)
pyautogui.click(clicks=2, interval=0.2, button='right') #해당 위치에서 총 2번 클릭하며, 클릭간의 시간은 0.2초입니다. 마우스는 오른쪽 버튼을 클릭합니다.

# 드래그
# 1초간 400, 400 위치로 이동 후, 절대 좌표 500, 500으로 2초간 드래그
pyautogui.click(400, 400, duration=1)
pyautogui.dragTo(500, 500, 2, button='left')

pyautogui.click()
# 현재 마우스 위치 기준으로 300, 300 범위만큼 왼쪽 버튼으로 드래그
pyautogui.dragRel(300, 300, 2, button='left')


# 스크롤
pyautogui.scroll(-100) 
pyautogui.scroll(100) 