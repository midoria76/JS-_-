import pyautogui

pyautogui.click(500, 500)

# 쓰기(타자)
pyautogui.write('Hello world!', interval=0.2) 

# 입력
pyautogui.press('Enter')

#단축키
pyautogui.hotkey("ctrl", "c")