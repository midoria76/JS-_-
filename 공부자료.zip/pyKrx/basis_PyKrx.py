from pykrx import stock
import pandas

df = stock.get_market_ohlcv_by_date(fromdate="20101015", todate="202201020", ticker='005930')
print(df)