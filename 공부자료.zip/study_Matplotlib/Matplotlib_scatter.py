import matplotlib.pyplot as plt
import numpy as np

np.random.seed(0)

n = 50
x = np.random.rand(n)
y = np.random.rand(n)
area = (30 * np.random.rand(n))**2
colors = np.random.rand(n)

plt.scatter(x, y, s=area, c=colors, alpha=0.5, cmap='Spectral')
plt.colorbar()
plt.show()

# np.random.rand(n) 1 * n 배열, 수는 무작위     
# np.random.rand(x,y) x*y 배열, 수는 무작위 
# np의 arange와 range는 똑같은 기능, 다만 Type형식의 차이임
