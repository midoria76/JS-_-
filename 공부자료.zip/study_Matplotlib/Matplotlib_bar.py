import matplotlib.pyplot as plt

x = [1,2,3,4,5]
y = [10,30,45,12,6]

plt.bar(x,y,color ='blue', width=0.5)
plt.show() 