import matplotlib.pyplot as plt

ratio = [10,35,25,7,23]
labels = ['chicken', 'pizza','hamburger','kimchi','others']

colors = ['#ff9999', '#ffc000', '#8fd9b6', '#f395d0', '#f2d560']
wedgeprops={'width': 0.7, 'edgecolor': 'w', 'linewidth': 5}

plt.pie(ratio, labels = labels, autopct='%.1d%%', colors = colors, wedgeprops=wedgeprops)
plt.show()