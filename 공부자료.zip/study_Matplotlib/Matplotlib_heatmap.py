import matplotlib.pyplot as plt
import numpy as np

arr = np.random.standard_normal((30, 40))
arr*=10

plt.matshow(arr)
plt.colorbar()

plt.show()