import pandas as pd

df = pd.DataFrame(
    [
        [4000,20000,10000],
        [5000,8000,11000],
        [6000,9000,12000]
    ], 
    index=['apple','bannana','cherry'],
    columns=['2020-03-03','2020-03-04','2020-03-05']
)

print(df)
print(df.index)
print(df.columns)
#print(df.values)
#print(df.describe())
print(df['2020-03-03'])
print(df.loc['apple'])