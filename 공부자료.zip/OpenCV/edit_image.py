import cv2
import numpy as np
width = 640 
height = 480
capture = cv2.VideoCapture(0) #0번 경로 카메라
capture.set(cv2.CAP_PROP_FRAME_WIDTH, width)
capture.set(cv2.CAP_PROP_FRAME_HEIGHT, height)
#capture.set(속성, 속성값)
while True: #프레임 딜레이 33ms마다....
    button = cv2.waitKey(13)
    if button == ord('q'):
        break
    if button == 13:
        ret1, save_pic = capture.read()
        cv2.imshow('capture_show', save_pic)
    if button == ord('i'):
        try:
            edit_pic = ~save_pic
            cv2.imshow('edit_pic', edit_pic)
        except:
            print("Capture with Enter")
    if button == ord('l'):
        try:
            matrix = cv2.getRotationMatrix2D((width / 2, height / 2), 45, 2)
            #회전 연산 행렬, (width/2, height/2) 점을 중심으로 45도 각도로 회전하며 배율은 2배
            edit_pic = cv2.warpAffine(save_pic, matrix, (width, height))
            #사진의 픽셀을 행렬과 곱한 값을 추출...
            cv2.imshow('edit_pic', edit_pic)
        except:
            print("Error")
            
    if button == ord('b'):
        try:
            edit_pic = np.clip(save_pic.astype('int32') + 50, 0, 255).astype('uint8')
            #기존 사진의 np를 int32값으로 변환하고 50씩 더함, 0보다 작은 값은 0
            #255 보다 큰 값을 255 처리해줌 그리고 다시 uint8로 형변환.
            #clip는 최댓값, 최솟값을 정해주는 연산임
            cv2.imshow('edit_pic', edit_pic)
        except:
            print('Error')
            
    if button == ord('f'):
        try:
            edit_pic = cv2.flip(save_pic, 0)
            #flipCode 0 = 상하대칭(x축), 1 = 좌우대칭(y축), 2 = 상하좌우 대칭(xy축)
            cv2.imshow('edit_pic', edit_pic)
        except:
            print('Error')
    
    ret, frame = capture.read()
    cv2.imshow("VideoFrame",frame) #VideoFrame이라는 창 이름으로 이미지 갱신
    
capture.release()
cv2.destroyAllWindows()