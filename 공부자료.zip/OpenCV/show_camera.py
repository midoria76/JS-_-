import cv2

capture = cv2.VideoCapture(0) #0번 경로 카메라
capture.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
capture.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
#capture.set(속성, 속성값)

while cv2.waitKey(33) < 0: #프레임 딜레이 33ms마다....
    ret, frame = capture.read()
    cv2.imshow("VideoFrame",frame)
    cv2.imshow("VideoFrame2", frame)

capture.release()
cv2.destroyAllWindows()