import numpy as np
import cv2

image = cv2.imread('C:/Users/Galaxy Book Pro 360/Downloads/cats/3.jpg', cv2.IMREAD_UNCHANGED)
cv2.imshow("Moon", image)
cv2.waitKey(0)
cv2.destroyAllwindows()