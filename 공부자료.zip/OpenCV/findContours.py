import numpy as np
import cv2

image = cv2.imread('C:/Users/Galaxy Book Pro 360/Downloads/cats/3.jpg', cv2.IMREAD_UNCHANGED)


capture = cv2.VideoCapture(0) #0번 경로 카메라
capture.set(cv2.CAP_PROP_FRAME_WIDTH, 960)
capture.set(cv2.CAP_PROP_FRAME_HEIGHT, 960)
#capture.set(속성, 속성값)

while cv2.waitKey(33) < 0: #프레임 딜레이 33ms마다....
    ret, frame = capture.read()
    ret, frame1 = capture.read()
    print(type(frame))
    edit_frame = np.clip(frame.astype('int32')-20, 0, 255).astype('uint8')

    frame2 = cv2.cvtColor(edit_frame, cv2.COLOR_BGR2GRAY) #영상은 따로 cvtColor로 빼내자... 
    #adaptive threshold사용하기 위해 그레이 컬러로!!
    
    ad_dst1 = cv2.adaptiveThreshold(frame2, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, 9, 5)
    ad_dst2 = cv2.adaptiveThreshold(frame2, 255, cv2.ADAPTIVE_THRESH_MEAN_C, cv2.THRESH_BINARY, 9, 5)
    #################### 중요 ^ adaptiveThreshold ###################3
    #frame에서 색상이 160보다 크냐 작냐에 따라 지정 값으로 지정함.
    #method 
    # gray = cv2.cvtColor(dst2, cv2.COLOR_BGR2GRAY)
    contours, hierarchy = cv2.findContours(ad_dst2, cv2.RETR_TREE, cv2.CHAIN_APPROX_TC89_KCOS)
    for contour in contours:
        cv2.drawContours(frame, [contour], -1, (0,255,0),2)
    
    # for cnt in contours:
    #     x, y, w, h = cv2.boundingRect(cnt)
    #     cv2.rectangle(frame1, (x, y), (x + w, y + h), (0, 255, 0), 2)
    
    for cnt in contours:
        rect = cv2.minAreaRect(cnt)
        box = cv2.boxPoints(rect)
        box = np.int0(box)
        cv2.drawContours(frame1,[box],0,(0,0,255),2)
    # cv2.imshow("VideoFrame",dst) #VideoFrame이라는 창 이름으로 이미지 갱신
    # cv2.imshow("1", ad_dst1)
    cv2.imshow("2", ad_dst2)
    cv2.imshow("3", frame)
    # cv2.imshow("4", frame1)