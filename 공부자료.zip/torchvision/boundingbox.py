from PIL import Image, ImageDraw

img = Image.open('C:/Users/Galaxy Book Pro 360/Desktop/내꺼/Download정리파일/jpg/1117이현민.jpg').convert('RGB')
img.show()

draw = ImageDraw.Draw(img)
draw.rectangle((100,100,300,300), outline=(0,255,0), width = 3)

img.show()

