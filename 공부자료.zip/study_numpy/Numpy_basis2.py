import numpy as np

arr0 = np.zeros((10,5)) #0으로 가득찬 10행 5열 배열 제작
arr1 = np.ones((3,5,7)) #1로 가득찬 3차원 배열 제작..
#print(arr0)
#print(arr1)

arg = np.arange(1, 40, 2) #1부터 40까지 2씩 증가하는 배열 제작 (1차원)
print(arg)
arg1 = arg.reshape((4,-1)) #arg를 4행 ~열로 지정 (-1은 알아서 맞춰주세요~ 를 뜻함)
print(arg1) 

new_arr = arg1[1:,1:4] #arg1배열에서 부분적으로 하는 새로운 배열 생성
print(new_arr)

