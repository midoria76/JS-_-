import numpy as np

a = [[[1,2,3],[4,5,6]],[[7,8,9],[10,11,12]]]
arr = np.array(a)
#기본 List a를 numpy 배열 arr로 전환

print(arr.ndim) #arr의 차원 즉 괄호의 갯수를 의미함
print(arr.size) #arr의 원소가 몇개인지 출력
print(arr.shape) #arr의 형태가 어떻게 띄는지 보여줌

